'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import Link from 'next/link'
import { Button } from '@/components/ui/button'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Textarea } from '@/components/ui/textarea'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select'
import { Spinner } from '@/components/ui/spinner'
import { ArrowLeft, PawPrint } from 'lucide-react'
import { toast } from 'sonner'
import { createPet } from '@/lib/api'

export default function NewPetPage() {
  const router = useRouter()
  const [isLoading, setIsLoading] = useState(false)
  const [formData, setFormData] = useState({
    nombre: '',
    especie: 'perro' as 'perro' | 'gato' | 'otro',
    raza: '',
    color: '',
    fecha_nacimiento: '',
    foto_url: '',
    notas_medicas: '',
  })

  async function handleSubmit(e: React.FormEvent) {
    e.preventDefault()
    setIsLoading(true)

    try {
      const pet = await createPet({
        ...formData,
        raza: formData.raza || null,
        color: formData.color || null,
        fecha_nacimiento: formData.fecha_nacimiento || null,
        foto_url: formData.foto_url || null,
        notas_medicas: formData.notas_medicas || null,
      })
      toast.success('Mascota registrada exitosamente')
      router.push(`/dashboard/pets/${pet.id}`)
    } catch (error) {
      toast.error(error instanceof Error ? error.message : 'Error al registrar mascota')
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <div className="flex items-center gap-4">
        <Link href="/dashboard/pets">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="w-5 h-5" />
          </Button>
        </Link>
        <div>
          <h1 className="text-2xl font-bold">Nueva Mascota</h1>
          <p className="text-muted-foreground">Registra los datos de tu mascota</p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center gap-3">
            <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center">
              <PawPrint className="w-6 h-6 text-primary" />
            </div>
            <div>
              <CardTitle>Informacion de la Mascota</CardTitle>
              <CardDescription>
                Completa los datos para generar el codigo QR
              </CardDescription>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-6">
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <div className="space-y-2">
                <Label htmlFor="nombre">Nombre *</Label>
                <Input
                  id="nombre"
                  placeholder="Nombre de tu mascota"
                  value={formData.nombre}
                  onChange={(e) => setFormData({ ...formData, nombre: e.target.value })}
                  required
                  disabled={isLoading}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="especie">Especie *</Label>
                <Select
                  value={formData.especie}
                  onValueChange={(value: 'perro' | 'gato' | 'otro') =>
                    setFormData({ ...formData, especie: value })
                  }
                  disabled={isLoading}
                >
                  <SelectTrigger id="especie">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="perro">Perro</SelectItem>
                    <SelectItem value="gato">Gato</SelectItem>
                    <SelectItem value="otro">Otro</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="raza">Raza</Label>
                <Input
                  id="raza"
                  placeholder="Ej: Labrador, Siames..."
                  value={formData.raza}
                  onChange={(e) => setFormData({ ...formData, raza: e.target.value })}
                  disabled={isLoading}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="color">Color</Label>
                <Input
                  id="color"
                  placeholder="Ej: Negro, Blanco, Manchado..."
                  value={formData.color}
                  onChange={(e) => setFormData({ ...formData, color: e.target.value })}
                  disabled={isLoading}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="fecha_nacimiento">Fecha de Nacimiento</Label>
                <Input
                  id="fecha_nacimiento"
                  type="date"
                  value={formData.fecha_nacimiento}
                  onChange={(e) => setFormData({ ...formData, fecha_nacimiento: e.target.value })}
                  disabled={isLoading}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="foto_url">URL de Foto</Label>
                <Input
                  id="foto_url"
                  type="url"
                  placeholder="https://..."
                  value={formData.foto_url}
                  onChange={(e) => setFormData({ ...formData, foto_url: e.target.value })}
                  disabled={isLoading}
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notas_medicas">Notas Medicas</Label>
              <Textarea
                id="notas_medicas"
                placeholder="Alergias, medicamentos, condiciones especiales..."
                rows={3}
                value={formData.notas_medicas}
                onChange={(e) => setFormData({ ...formData, notas_medicas: e.target.value })}
                disabled={isLoading}
              />
            </div>

            <div className="flex gap-4">
              <Button type="submit" className="flex-1" disabled={isLoading}>
                {isLoading ? (
                  <>
                    <Spinner className="mr-2" />
                    Registrando...
                  </>
                ) : (
                  'Registrar Mascota'
                )}
              </Button>
              <Link href="/dashboard/pets">
                <Button type="button" variant="outline" disabled={isLoading}>
                  Cancelar
                </Button>
              </Link>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
