export interface User {
  id: number
  email: string
  nombre: string
  telefono: string | null
  es_admin: boolean
  creado_en: string
  actualizado_en: string
}

export interface Pet {
  id: number
  nombre: string
  especie: 'perro' | 'gato' | 'otro'
  raza: string | null
  color: string | null
  fecha_nacimiento: string | null
  foto_url: string | null
  notas_medicas: string | null
  usuario_id: number
  creado_en: string
  actualizado_en: string
}

export interface QRCode {
  id: number
  codigo: string
  mascota_id: number
  activo: boolean
  creado_en: string
}

export interface Scan {
  id: number
  codigo_qr_id: number
  latitud: number | null
  longitud: number | null
  direccion: string | null
  ip_address: string | null
  user_agent: string | null
  escaneado_en: string
}

export interface PetWithQR extends Pet {
  qr_codes: QRCode[]
  owner: Pick<User, 'nombre' | 'telefono'>
}

export interface ScanWithLocation extends Scan {
  pet_name?: string
}

export interface DashboardStats {
  total_pets: number
  total_scans: number
  active_qrs: number
  recent_scans: ScanWithLocation[]
}

export interface AdminStats {
  total_users: number
  total_pets: number
  total_scans: number
  total_qrs: number
  scans_by_day: { date: string; count: number }[]
  pets_by_species: { species: string; count: number }[]
  recent_scans: (Scan & { pet_name: string; owner_name: string })[]
}

export interface LoginCredentials {
  email: string
  password: string
}

export interface RegisterData extends LoginCredentials {
  nombre: string
  telefono?: string
}

export interface AuthResponse {
  user: User
  access_token: string
}

export interface ApiError {
  detail: string
}

export type PetFormData = Omit<Pet, 'id' | 'usuario_id' | 'creado_en' | 'actualizado_en'>
