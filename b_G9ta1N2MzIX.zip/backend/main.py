import os
from contextlib import asynccontextmanager
from typing import Any

import asyncpg
import fastapi
import fastapi.middleware.cors
from pydantic import BaseModel

# Database pool
pool: asyncpg.Pool | None = None


async def get_pool() -> asyncpg.Pool:
    global pool
    if pool is None:
        pool = await asyncpg.create_pool(dsn=os.environ["DATABASE_URL"])
    return pool


@asynccontextmanager
async def lifespan(app: fastapi.FastAPI):
    # Startup: create connection pool
    global pool
    pool = await asyncpg.create_pool(dsn=os.environ.get("DATABASE_URL", ""))
    yield
    # Shutdown: close pool
    if pool:
        await pool.close()


app = fastapi.FastAPI(lifespan=lifespan)

app.add_middleware(
    fastapi.middleware.cors.CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# ============== HEALTH ==============
@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}


# ============== SCHEMAS ==============
class UsuarioCreate(BaseModel):
    email: str
    nombre: str
    telefono: str | None = None
    password_hash: str | None = None
    provider: str = "credentials"
    provider_id: str | None = None
    rol: str = "usuario"
    avatar_url: str | None = None


class UsuarioResponse(BaseModel):
    id: str
    email: str
    nombre: str
    telefono: str | None
    rol: str
    avatar_url: str | None
    created_at: str


class MascotaCreate(BaseModel):
    nombre: str
    especie: str
    raza: str | None = None
    color: str | None = None
    edad_aproximada: str | None = None
    foto_url: str | None = None
    notas: str | None = None
    estado: str = "en_casa"


class MascotaUpdate(BaseModel):
    nombre: str | None = None
    especie: str | None = None
    raza: str | None = None
    color: str | None = None
    edad_aproximada: str | None = None
    foto_url: str | None = None
    notas: str | None = None
    estado: str | None = None


class MascotaResponse(BaseModel):
    id: str
    usuario_id: str
    nombre: str
    especie: str
    raza: str | None
    color: str | None
    edad_aproximada: str | None
    foto_url: str | None
    notas: str | None
    estado: str
    created_at: str


class EscaneoCreate(BaseModel):
    latitud: float | None = None
    longitud: float | None = None
    direccion_aproximada: str | None = None
    mensaje_encontrador: str | None = None
    telefono_encontrador: str | None = None


class EscaneoResponse(BaseModel):
    id: str
    qr_id: str
    latitud: float | None
    longitud: float | None
    direccion_aproximada: str | None
    mensaje_encontrador: str | None
    telefono_encontrador: str | None
    created_at: str


class QRPublicResponse(BaseModel):
    mascota_nombre: str
    mascota_especie: str
    mascota_raza: str | None
    mascota_color: str | None
    mascota_foto_url: str | None
    mascota_estado: str
    dueno_nombre: str
    dueno_telefono_parcial: str | None
    whatsapp_link: str | None


class StatsResponse(BaseModel):
    total_usuarios: int
    total_mascotas: int
    total_escaneos: int
    mascotas_perdidas: int


# ============== AUTH HELPERS ==============
def get_user_id_from_header(request: fastapi.Request) -> str | None:
    """Extract user ID from Authorization header (simplified for NextAuth JWT)"""
    auth_header = request.headers.get("Authorization", "")
    if auth_header.startswith("Bearer "):
        # In production, decode and validate the JWT
        # For now, we'll use a custom header for user ID
        return request.headers.get("X-User-Id")
    return None


def require_user(request: fastapi.Request) -> str:
    """Require authenticated user"""
    user_id = get_user_id_from_header(request)
    if not user_id:
        raise fastapi.HTTPException(status_code=401, detail="Not authenticated")
    return user_id


def require_admin(request: fastapi.Request) -> str:
    """Require admin user - check via X-User-Role header"""
    user_id = require_user(request)
    role = request.headers.get("X-User-Role", "usuario")
    if role != "admin":
        raise fastapi.HTTPException(status_code=403, detail="Admin access required")
    return user_id


# ============== USUARIOS ==============
@app.get("/usuarios/me")
async def get_current_user(request: fastapi.Request) -> dict[str, Any]:
    user_id = require_user(request)
    p = await get_pool()
    row = await p.fetchrow("SELECT * FROM usuarios WHERE id = $1", user_id)
    if not row:
        raise fastapi.HTTPException(status_code=404, detail="User not found")
    return dict(row)


@app.post("/usuarios")
async def create_user(data: UsuarioCreate) -> dict[str, Any]:
    p = await get_pool()
    row = await p.fetchrow(
        """
        INSERT INTO usuarios (email, nombre, telefono, password_hash, provider, provider_id, rol, avatar_url)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
        ON CONFLICT (email) DO UPDATE SET
            nombre = EXCLUDED.nombre,
            telefono = COALESCE(EXCLUDED.telefono, usuarios.telefono),
            provider = EXCLUDED.provider,
            provider_id = EXCLUDED.provider_id,
            avatar_url = COALESCE(EXCLUDED.avatar_url, usuarios.avatar_url),
            updated_at = NOW()
        RETURNING *
        """,
        data.email,
        data.nombre,
        data.telefono,
        data.password_hash,
        data.provider,
        data.provider_id,
        data.rol,
        data.avatar_url,
    )
    return dict(row)


@app.get("/usuarios/{email}/by-email")
async def get_user_by_email(email: str) -> dict[str, Any] | None:
    p = await get_pool()
    row = await p.fetchrow("SELECT * FROM usuarios WHERE email = $1", email)
    if not row:
        return None
    return dict(row)


@app.patch("/usuarios/me")
async def update_current_user(
    request: fastapi.Request, nombre: str | None = None, telefono: str | None = None
) -> dict[str, Any]:
    user_id = require_user(request)
    p = await get_pool()
    updates = []
    values = []
    idx = 1

    if nombre:
        updates.append(f"nombre = ${idx}")
        values.append(nombre)
        idx += 1
    if telefono:
        updates.append(f"telefono = ${idx}")
        values.append(telefono)
        idx += 1

    if not updates:
        raise fastapi.HTTPException(status_code=400, detail="No fields to update")

    updates.append("updated_at = NOW()")
    values.append(user_id)

    query = f"UPDATE usuarios SET {', '.join(updates)} WHERE id = ${idx} RETURNING *"
    row = await p.fetchrow(query, *values)
    return dict(row)


# ============== MASCOTAS ==============
@app.get("/mascotas")
async def list_mascotas(request: fastapi.Request) -> list[dict[str, Any]]:
    user_id = require_user(request)
    p = await get_pool()
    rows = await p.fetch(
        "SELECT * FROM mascotas WHERE usuario_id = $1 ORDER BY created_at DESC",
        user_id,
    )
    return [dict(r) for r in rows]


@app.post("/mascotas")
async def create_mascota(
    request: fastapi.Request, data: MascotaCreate
) -> dict[str, Any]:
    user_id = require_user(request)
    p = await get_pool()
    row = await p.fetchrow(
        """
        INSERT INTO mascotas (usuario_id, nombre, especie, raza, color, edad_aproximada, foto_url, notas, estado)
        VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9)
        RETURNING *
        """,
        user_id,
        data.nombre,
        data.especie,
        data.raza,
        data.color,
        data.edad_aproximada,
        data.foto_url,
        data.notas,
        data.estado,
    )
    return dict(row)


@app.get("/mascotas/{mascota_id}")
async def get_mascota(request: fastapi.Request, mascota_id: str) -> dict[str, Any]:
    user_id = require_user(request)
    p = await get_pool()
    row = await p.fetchrow(
        "SELECT * FROM mascotas WHERE id = $1 AND usuario_id = $2", mascota_id, user_id
    )
    if not row:
        raise fastapi.HTTPException(status_code=404, detail="Pet not found")
    return dict(row)


@app.patch("/mascotas/{mascota_id}")
async def update_mascota(
    request: fastapi.Request, mascota_id: str, data: MascotaUpdate
) -> dict[str, Any]:
    user_id = require_user(request)
    p = await get_pool()

    # Build dynamic update query
    updates = []
    values = []
    idx = 1

    for field, value in data.model_dump(exclude_none=True).items():
        updates.append(f"{field} = ${idx}")
        values.append(value)
        idx += 1

    if not updates:
        raise fastapi.HTTPException(status_code=400, detail="No fields to update")

    updates.append("updated_at = NOW()")
    values.extend([mascota_id, user_id])

    query = f"UPDATE mascotas SET {', '.join(updates)} WHERE id = ${idx} AND usuario_id = ${idx + 1} RETURNING *"
    row = await p.fetchrow(query, *values)
    if not row:
        raise fastapi.HTTPException(status_code=404, detail="Pet not found")
    return dict(row)


@app.delete("/mascotas/{mascota_id}")
async def delete_mascota(request: fastapi.Request, mascota_id: str) -> dict[str, str]:
    user_id = require_user(request)
    p = await get_pool()
    result = await p.execute(
        "DELETE FROM mascotas WHERE id = $1 AND usuario_id = $2", mascota_id, user_id
    )
    if result == "DELETE 0":
        raise fastapi.HTTPException(status_code=404, detail="Pet not found")
    return {"message": "Pet deleted successfully"}


@app.patch("/mascotas/{mascota_id}/estado")
async def update_mascota_estado(
    request: fastapi.Request, mascota_id: str, estado: str
) -> dict[str, Any]:
    user_id = require_user(request)
    if estado not in ["en_casa", "perdido"]:
        raise fastapi.HTTPException(status_code=400, detail="Invalid state")
    p = await get_pool()
    row = await p.fetchrow(
        "UPDATE mascotas SET estado = $1, updated_at = NOW() WHERE id = $2 AND usuario_id = $3 RETURNING *",
        estado,
        mascota_id,
        user_id,
    )
    if not row:
        raise fastapi.HTTPException(status_code=404, detail="Pet not found")
    return dict(row)


# ============== QR CODES ==============
@app.post("/qr/generar/{mascota_id}")
async def generate_qr(request: fastapi.Request, mascota_id: str) -> dict[str, Any]:
    user_id = require_user(request)
    p = await get_pool()

    # Verify pet belongs to user
    pet = await p.fetchrow(
        "SELECT * FROM mascotas WHERE id = $1 AND usuario_id = $2", mascota_id, user_id
    )
    if not pet:
        raise fastapi.HTTPException(status_code=404, detail="Pet not found")

    # Check if QR already exists
    existing = await p.fetchrow(
        "SELECT * FROM codigos_qr WHERE mascota_id = $1", mascota_id
    )
    if existing:
        return dict(existing)

    # Generate unique code
    import secrets

    codigo = secrets.token_urlsafe(6)[:8].upper()

    row = await p.fetchrow(
        "INSERT INTO codigos_qr (codigo, mascota_id) VALUES ($1, $2) RETURNING *",
        codigo,
        mascota_id,
    )
    return dict(row)


@app.get("/qr/{codigo}")
async def get_qr_public(codigo: str) -> QRPublicResponse:
    """Public endpoint - anyone can access when scanning QR"""
    p = await get_pool()

    row = await p.fetchrow(
        """
        SELECT 
            m.nombre as mascota_nombre,
            m.especie as mascota_especie,
            m.raza as mascota_raza,
            m.color as mascota_color,
            m.foto_url as mascota_foto_url,
            m.estado as mascota_estado,
            u.nombre as dueno_nombre,
            u.telefono as dueno_telefono
        FROM codigos_qr qr
        JOIN mascotas m ON qr.mascota_id = m.id
        JOIN usuarios u ON m.usuario_id = u.id
        WHERE qr.codigo = $1 AND qr.activo = true
        """,
        codigo,
    )

    if not row:
        raise fastapi.HTTPException(status_code=404, detail="QR code not found")

    # Partially hide phone number
    telefono = row["dueno_telefono"]
    telefono_parcial = None
    whatsapp_link = None

    if telefono:
        # Show only last 4 digits
        telefono_parcial = f"***{telefono[-4:]}" if len(telefono) >= 4 else "***"
        # Generate WhatsApp link
        telefono_limpio = "".join(filter(str.isdigit, telefono))
        mensaje = f"Hola, encontré a {row['mascota_nombre']}!"
        whatsapp_link = f"https://wa.me/{telefono_limpio}?text={mensaje.replace(' ', '%20')}"

    return QRPublicResponse(
        mascota_nombre=row["mascota_nombre"],
        mascota_especie=row["mascota_especie"],
        mascota_raza=row["mascota_raza"],
        mascota_color=row["mascota_color"],
        mascota_foto_url=row["mascota_foto_url"],
        mascota_estado=row["mascota_estado"],
        dueno_nombre=row["dueno_nombre"],
        dueno_telefono_parcial=telefono_parcial,
        whatsapp_link=whatsapp_link,
    )


@app.post("/qr/{codigo}/escaneo")
async def register_scan(codigo: str, data: EscaneoCreate) -> dict[str, Any]:
    """Public endpoint - register a scan with optional location"""
    p = await get_pool()

    # Get QR code
    qr = await p.fetchrow(
        "SELECT id FROM codigos_qr WHERE codigo = $1 AND activo = true", codigo
    )
    if not qr:
        raise fastapi.HTTPException(status_code=404, detail="QR code not found")

    row = await p.fetchrow(
        """
        INSERT INTO escaneos (qr_id, latitud, longitud, direccion_aproximada, mensaje_encontrador, telefono_encontrador)
        VALUES ($1, $2, $3, $4, $5, $6)
        RETURNING *
        """,
        qr["id"],
        data.latitud,
        data.longitud,
        data.direccion_aproximada,
        data.mensaje_encontrador,
        data.telefono_encontrador,
    )
    return dict(row)


@app.get("/qr/mascota/{mascota_id}")
async def get_qr_for_mascota(
    request: fastapi.Request, mascota_id: str
) -> dict[str, Any] | None:
    user_id = require_user(request)
    p = await get_pool()

    # Verify ownership
    pet = await p.fetchrow(
        "SELECT * FROM mascotas WHERE id = $1 AND usuario_id = $2", mascota_id, user_id
    )
    if not pet:
        raise fastapi.HTTPException(status_code=404, detail="Pet not found")

    qr = await p.fetchrow("SELECT * FROM codigos_qr WHERE mascota_id = $1", mascota_id)
    if not qr:
        return None
    return dict(qr)


# ============== ESCANEOS (for owner) ==============
@app.get("/escaneos/mascota/{mascota_id}")
async def get_escaneos_by_mascota(
    request: fastapi.Request, mascota_id: str
) -> list[dict[str, Any]]:
    user_id = require_user(request)
    p = await get_pool()

    # Verify ownership
    pet = await p.fetchrow(
        "SELECT * FROM mascotas WHERE id = $1 AND usuario_id = $2", mascota_id, user_id
    )
    if not pet:
        raise fastapi.HTTPException(status_code=404, detail="Pet not found")

    rows = await p.fetch(
        """
        SELECT e.* FROM escaneos e
        JOIN codigos_qr qr ON e.qr_id = qr.id
        WHERE qr.mascota_id = $1
        ORDER BY e.created_at DESC
        """,
        mascota_id,
    )
    return [dict(r) for r in rows]


@app.get("/escaneos/usuario")
async def get_escaneos_by_user(request: fastapi.Request) -> list[dict[str, Any]]:
    user_id = require_user(request)
    p = await get_pool()

    rows = await p.fetch(
        """
        SELECT e.*, m.nombre as mascota_nombre, m.foto_url as mascota_foto
        FROM escaneos e
        JOIN codigos_qr qr ON e.qr_id = qr.id
        JOIN mascotas m ON qr.mascota_id = m.id
        WHERE m.usuario_id = $1
        ORDER BY e.created_at DESC
        LIMIT 50
        """,
        user_id,
    )
    return [dict(r) for r in rows]


# ============== ADMIN ==============
@app.get("/admin/stats")
async def get_admin_stats(request: fastapi.Request) -> StatsResponse:
    require_admin(request)
    p = await get_pool()

    total_usuarios = await p.fetchval("SELECT COUNT(*) FROM usuarios")
    total_mascotas = await p.fetchval("SELECT COUNT(*) FROM mascotas")
    total_escaneos = await p.fetchval("SELECT COUNT(*) FROM escaneos")
    mascotas_perdidas = await p.fetchval(
        "SELECT COUNT(*) FROM mascotas WHERE estado = 'perdido'"
    )

    return StatsResponse(
        total_usuarios=total_usuarios or 0,
        total_mascotas=total_mascotas or 0,
        total_escaneos=total_escaneos or 0,
        mascotas_perdidas=mascotas_perdidas or 0,
    )


@app.get("/admin/usuarios")
async def admin_list_usuarios(request: fastapi.Request) -> list[dict[str, Any]]:
    require_admin(request)
    p = await get_pool()
    rows = await p.fetch("SELECT * FROM usuarios ORDER BY created_at DESC")
    return [dict(r) for r in rows]


@app.get("/admin/mascotas")
async def admin_list_mascotas(request: fastapi.Request) -> list[dict[str, Any]]:
    require_admin(request)
    p = await get_pool()
    rows = await p.fetch(
        """
        SELECT m.*, u.nombre as dueno_nombre, u.email as dueno_email
        FROM mascotas m
        JOIN usuarios u ON m.usuario_id = u.id
        ORDER BY m.created_at DESC
        """
    )
    return [dict(r) for r in rows]


@app.get("/admin/escaneos")
async def admin_list_escaneos(request: fastapi.Request) -> list[dict[str, Any]]:
    require_admin(request)
    p = await get_pool()
    rows = await p.fetch(
        """
        SELECT e.*, m.nombre as mascota_nombre, u.nombre as dueno_nombre
        FROM escaneos e
        JOIN codigos_qr qr ON e.qr_id = qr.id
        JOIN mascotas m ON qr.mascota_id = m.id
        JOIN usuarios u ON m.usuario_id = u.id
        ORDER BY e.created_at DESC
        LIMIT 100
        """
    )
    return [dict(r) for r in rows]


@app.delete("/admin/usuarios/{usuario_id}")
async def admin_delete_usuario(
    request: fastapi.Request, usuario_id: str
) -> dict[str, str]:
    require_admin(request)
    p = await get_pool()
    await p.execute("DELETE FROM usuarios WHERE id = $1", usuario_id)
    return {"message": "User deleted"}
